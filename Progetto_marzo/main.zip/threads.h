#ifndef THREADS_H
#define THREADS_H

#include <pthread.h>
#include "queue.h"

// Struttura per i parametri del worker
typedef struct {
    int worker_id;
} WorkerArgs;

// Variabili condivise (definite in threads.c)
extern Queue Q;
extern pthread_mutex_t mutex;
extern pthread_cond_t cond_not_full;
extern pthread_cond_t cond_not_empty;
extern pthread_cond_t cond_results;
extern int production_finished;
extern int results_count;
extern int *array;
extern int N, k, num_workers, capacity;

// Dichiarazioni delle funzioni dei thread
void* thread_master(void *arg);
void* thread_worker(void *arg);

#endif
