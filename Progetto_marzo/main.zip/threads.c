#include "threads.h"
#include <stdlib.h>
#include <stdio.h>

// Definizione delle variabili globali
Queue Q;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t cond_not_full = PTHREAD_COND_INITIALIZER;
pthread_cond_t cond_not_empty = PTHREAD_COND_INITIALIZER;
pthread_cond_t cond_results = PTHREAD_COND_INITIALIZER;
int production_finished = 0;
int results_count = 0;
int *array;
int N, k, num_workers, capacity;

void* thread_master(void* arg) {
    int i = 0;
    // Fase 1: Produzione dei gruppi
    while (i < N) {
        Group *grp = malloc(sizeof(Group));
        if (!grp) { perror("malloc Group"); exit(EXIT_FAILURE); }
        grp->pairs = malloc(k * sizeof(Pair));
        if (!grp->pairs) { perror("malloc pairs"); exit(EXIT_FAILURE); }
        grp->max_pairs = k;
        grp->num_pairs = 0;

        while (grp->num_pairs < k && i < N) {
            if (i + 1 < N) {
                grp->pairs[grp->num_pairs].a = array[i];
                grp->pairs[grp->num_pairs].b = array[i + 1];
                grp->num_pairs++;
                i += 2;
            } else {
                grp->pairs[grp->num_pairs].a = array[i];
                grp->pairs[grp->num_pairs].b = 0;
                grp->num_pairs++;
                i++;
            }
        }

        // Prepara l'oggetto da inserire nella coda
        QueueItem *qi = malloc(sizeof(QueueItem));
        if (!qi) { perror("malloc QueueItem"); exit(EXIT_FAILURE); }
        qi->type = ITEM_GROUP;
        qi->data.group = grp;

        pthread_mutex_lock(&mutex);
        while (Q.count == Q.capacity)
            pthread_cond_wait(&cond_not_full, &mutex);
        queue_push(&Q, qi);
        printf("Master: pushed group with %d pairs (elements:", grp->num_pairs);
        for (int j = 0; j < grp->num_pairs; j++) {
            printf(" (%d,%d)", grp->pairs[j].a, grp->pairs[j].b);
        }
        printf(")\n");
        fflush(stdout);
        pthread_cond_signal(&cond_not_empty);
        pthread_mutex_unlock(&mutex);
    }

    // Fase 2: Notifica ai worker che la produzione è finita
    pthread_mutex_lock(&mutex);
    production_finished = 1;
    pthread_cond_broadcast(&cond_not_empty);
    pthread_mutex_unlock(&mutex);

    // Fase 3: Raccolta dei risultati parziali dai worker
    int final_sum = 0;
    pthread_mutex_lock(&mutex);
    while (results_count < num_workers)
        pthread_cond_wait(&cond_results, &mutex);

    for (int j = 0; j < num_workers; j++) {
        QueueItem *qi = queue_pop(&Q);
        if (qi == NULL || qi->type != ITEM_RESULT) {
            fprintf(stderr, "Master: errore nella raccolta dei risultati\n");
            exit(EXIT_FAILURE);
        }
        final_sum += *(qi->data.result);
        free(qi->data.result);
        free(qi);
        pthread_cond_signal(&cond_not_full);
    }
    pthread_mutex_unlock(&mutex);

    printf("Master: Somma finale: %d\n", final_sum);
    fflush(stdout);
    return NULL;
}

void* thread_worker(void* arg) {
    WorkerArgs *wargs = (WorkerArgs *) arg;
    int worker_id = wargs->worker_id;
    int partial_sum = 0;

    while (1) {
        pthread_mutex_lock(&mutex);
        // Se la coda è vuota e la produzione è finita, allora non ci sono più gruppi
        while (Q.count == 0 && !production_finished)
            pthread_cond_wait(&cond_not_empty, &mutex);

        // Se la coda non è vuota ma il primo oggetto è un risultato, vuol dire che altri worker hanno già finito
        if (Q.count > 0) {
            QueueItem *peek = queue_peek(&Q);
            if (peek->type == ITEM_RESULT && production_finished) {
                pthread_mutex_unlock(&mutex);
                break;
            }
        }

        if (Q.count == 0 && production_finished) {
            pthread_mutex_unlock(&mutex);
            break;
        }

        QueueItem *qi = queue_pop(&Q);
        pthread_cond_signal(&cond_not_full);
        pthread_mutex_unlock(&mutex);

        if (qi->type != ITEM_GROUP) {
            // Se per errore si preleva un risultato, lo rimettiamo e usciamo
            pthread_mutex_lock(&mutex);
            queue_push(&Q, qi);
            pthread_cond_signal(&cond_not_empty);
            pthread_mutex_unlock(&mutex);
            break;
        }

        Group *grp = qi->data.group;
        free(qi);

        printf("Worker %d: processing group with %d pairs (elements:", worker_id, grp->num_pairs);
        for (int i = 0; i < grp->num_pairs; i++) {
            printf(" (%d,%d)", grp->pairs[i].a, grp->pairs[i].b);
        }
        printf(")\n");
        fflush(stdout);
        for (int i = 0; i < grp->num_pairs; i++) {
            partial_sum += grp->pairs[i].a + grp->pairs[i].b;
        }
        free(grp->pairs);
        free(grp);
    }

    printf("Worker %d: finished with partial sum %d\n", worker_id, partial_sum);
    fflush(stdout);

    // Prepara l'oggetto risultato
    int *result = malloc(sizeof(int));
    if (!result) { perror("malloc result"); exit(EXIT_FAILURE); }
    *result = partial_sum;
    QueueItem *qi_result = malloc(sizeof(QueueItem));
    if (!qi_result) { perror("malloc QueueItem"); exit(EXIT_FAILURE); }
    qi_result->type = ITEM_RESULT;
    qi_result->data.result = result;

    pthread_mutex_lock(&mutex);
    while (Q.count == Q.capacity)
        pthread_cond_wait(&cond_not_full, &mutex);
    queue_push(&Q, qi_result);
    results_count++;
    pthread_cond_signal(&cond_results);
    pthread_cond_signal(&cond_not_empty);
    pthread_mutex_unlock(&mutex);

    free(wargs);
    return NULL;
}
