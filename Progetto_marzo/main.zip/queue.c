#include "queue.h"

void queue_init(Queue *q, int capacity) {
  q->capacity = capacity;
  q->count = 0;
  q->head = 0;
  q->tail = 0;
  q->items = malloc(capacity * sizeof(QueueItem *));
  if (!q->items) {
    perror("malloc queue items");
    exit(EXIT_FAILURE);
  }
}

void queue_push(Queue *q, QueueItem *item) {
  q->items[q->tail] = item;
  q->tail = (q->tail + 1) % q->capacity;
  q->count++;
}

QueueItem* queue_pop(Queue *q) {
  if(q->count == 0)
    return NULL;
  QueueItem *item = q->items[q->head];
  q->head = (q->head + 1) % q->capacity;
  q->count--;
  return item;
}

QueueItem* queue_peek(Queue *q) {
  if(q->count == 0)
    return NULL;
  return q->items[q->head];
}

void queue_destroy(Queue *q) {
  free(q->items);
}
