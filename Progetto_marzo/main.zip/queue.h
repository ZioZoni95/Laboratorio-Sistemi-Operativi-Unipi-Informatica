#ifndef QUEUE_H
#define QUEUE_H

#include <stdlib.h>
#include <stdio.h>

// Struttura per una coppia
typedef struct {
    int a;
    int b;
} Pair;

// Struttura per un gruppo di coppie
typedef struct {
    Pair *pairs;
    int num_pairs;
    int max_pairs; // k
} Group;

// Tipologia di oggetto nella coda
typedef enum {
    ITEM_GROUP,
    ITEM_RESULT
} ItemType;

// Oggetto da inserire nella coda: può essere un gruppo o un risultato
typedef struct {
    ItemType type;
    union {
        Group *group;
        int *result;
    } data;
} QueueItem;

// Struttura per la coda condivisa
typedef struct {
    QueueItem **items;    // Array di puntatori a QueueItem
    int head;
    int tail;
    int count;
    int capacity;
} Queue;

// Funzioni della coda
void queue_init(Queue *q, int capacity);
void queue_push(Queue *q, QueueItem *item);
QueueItem* queue_pop(Queue *q);
QueueItem* queue_peek(Queue *q);
void queue_destroy(Queue *q);

#endif
