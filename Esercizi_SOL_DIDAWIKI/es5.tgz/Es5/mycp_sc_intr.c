#include <stdarg.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>

#if !defined(BUFSIZE)
#define BUFSIZE 256
#endif

void print_error(const char * str, ...) {
    const char err[]="ERROR: ";
    va_list argp;
    char * p=(char *)malloc(strlen(str)+strlen(err)+10);
    if (!p) {
	perror("malloc");
        fprintf(stderr,"FATAL ERROR nella funzione 'error'\n");
        abort();
    }
    strcpy(p,err);
    strcpy(p+strlen(err), str);
    va_start(argp, str);
    vfprintf(stderr, p, argp);
    va_end(argp);
    free(p);
}


int main(int argc, char *argv[]) {
    if (argc < 3) {
	fprintf(stderr, "use: %s infile outfile [bufsize]\n", argv[0]);
	return EXIT_FAILURE;
    }
    char *infile  = argv[1];
    char *outfile = argv[2];
    size_t bufsize = BUFSIZE;
    if (argc >=4)
	bufsize = atol(argv[3]);
    
    int fin;
    if ((fin = open(infile, O_RDONLY)) == -1) {
	perror("ERROR: open");
	int err = errno;
	print_error("Aprendo il file in input %s : errno=%d\n", infile, err);	
	return err;
    }
    // imposto la maschera che voglio
    mode_t oldmask = umask(033);
    int fout;
    // creo il file con diritti 0640
    if ((fout = open(outfile, O_CREAT|O_WRONLY|O_TRUNC, S_IRUSR|S_IWUSR|S_IRGRP)) == -1) {
	perror("ERROR: open");
	err = errno;
	print_error("Creando il file in output %s : errno=%d\n", infile, errno);	
	return err;
    }
    // ripristino la vecchia maschera
    umask(oldmask);
    char *buf = malloc(bufsize*sizeof(char));
    if (!buf) {
	perror("malloc");
	return errno;
    }
    size_t len=0;
    while((len=read(fin,buf,bufsize))) {
	if (len == -1) {
	    if (errno==EINTR) continue;
	    perror("ERROR:read");
	    int err=errno;
	    print_error("Leggendo il file in input %s : errno=%d\n", infile, errno);
	    return err;
	}
	size_t wlen,written=0;
	while((wlen=write(fout,buf+written,len-written))) {
	    if (wlen == -1) {
		if (errno==EINTR) continue;
		perror("ERROR: write");
		int err=errno;
		print_error("Scrivendo il file in output %s : errno=%d\n", outfile, errno);
		return err;
	    }
	    written+=wlen;
	    if (written==len) break;
	}	       
    }
    if (fsync(fout) == -1 && errno != EINTR) {
	perror("ERROR: fsync");
	int err=errno;
	print_error("Facendo il flush del file in output %s : errno=%d\n", outfile, errno);
	return err;
    }
    if (close(fin) == -1 && errno != EINTR) {
	perror("close");
	int err=errno;
	print_error("Chiudendo il file in input %s : errno=%d\n", infile, errno);
	return err;
    }
    if (close(fout) == -1 && errno != EINTR) {
	perror("close");
	int err=errno;
	print_error("Chiudendo il file in output %s : errno=%d\n", outfile, errno);
	return err;
    }

    free(buf);
    return 0;
}
